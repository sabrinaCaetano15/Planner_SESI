const tipo = localStorage.getItem("tipo");
const nomeLogado = localStorage.getItem("nomeAlunoLogado");
if (!tipo) window.location.href = "login.html";

document.getElementById("nomeExibicao").innerText = tipo === "professor" ? "Professor" : nomeLogado;
if (tipo === "aluno") document.querySelector(".form-box").style.display = "none";

let dados = JSON.parse(localStorage.getItem("jogos")) || {
    "Vôlei": { Masculino: [], Feminino: [] }, "Handebol": { Masculino: [], Feminino: [] },
    "Futsal": { Masculino: [], Feminino: [] }, "Basquete": { Masculino: [], Feminino: [] }
};

let modalidade = "Vôlei", sexo = "Masculino";

document.querySelectorAll(".card").forEach(c => c.addEventListener("click", function() {
    document.querySelector(".card.active").classList.remove("active");
    this.classList.add("active"); modalidade = this.innerText; renderTabela();
}));

document.querySelectorAll(".sexo-btn").forEach(btn => btn.addEventListener("click", function() {
    document.querySelector(".sexo-btn.active").classList.remove("active");
    this.classList.add("active"); sexo = this.innerText; renderTabela();
}));

function adicionarAluno() {
    const nome = document.getElementById("nomeAluno").value.trim();
    const turma = document.getElementById("turmaAluno").value.trim();
    const pos = document.getElementById("posicaoAluno").value;
    if(!nome || !turma) return alert("Preencha tudo!");
    if(dados[modalidade][sexo].length >= 12) return alert("Time lotado!");
    dados[modalidade][sexo].push({ nome, turma, posicao: pos });
    localStorage.setItem("jogos", JSON.stringify(dados));
    document.getElementById("nomeAluno").value = "";
    document.getElementById("turmaAluno").value = "";
    renderTabela();
}

function renderTabela() {
    const lista = dados[modalidade][sexo];
    const busca = document.getElementById("busca").value.toLowerCase();
    const tabela = document.getElementById("tabela-alunos");
    tabela.innerHTML = "";
    lista.filter(a => a.nome.toLowerCase().includes(busca)).forEach((atleta, i) => {
        let acoes = tipo === "professor" ? 
            `<button onclick="editar(${i})" class="action-btn">✏️</button><button onclick="remover(${i})" class="action-btn">🗑️</button>` : 
            (atleta.nome === nomeLogado ? `<button onclick="remover(${i})" class="action-btn">❌</button>` : "-");
        tabela.innerHTML += `<tr><td>${atleta.nome}</td><td>${atleta.turma}</td><td><span class="badge ${atleta.posicao.toLowerCase()}">${atleta.posicao}</span></td><td style="text-align:right">${acoes}</td></tr>`;
    });
    document.getElementById("contador").innerText = `${lista.length}/12 jogadores`;
    let t = 0; for (let m in dados) t += (dados[m].Masculino.length + dados[m].Feminino.length);
    document.getElementById("totalGeral").innerText = t;
    document.getElementById("vagasRestantes").innerText = 48 - t;
}

function editar(i) {
    const n = prompt("Novo nome:", dados[modalidade][sexo][i].nome);
    if(n) { dados[modalidade][sexo][i].nome = n; localStorage.setItem("jogos", JSON.stringify(dados)); renderTabela(); }
}

function remover(i) {
    if(confirm("Remover?")) { dados[modalidade][sexo].splice(i, 1); localStorage.setItem("jogos", JSON.stringify(dados)); renderTabela(); }
}

function logout() { localStorage.removeItem("tipo"); localStorage.removeItem("nomeAlunoLogado"); window.location.href = "login.html"; }
renderTabela();
