function login() {
    const usuario = document.getElementById("usuario").value.trim();
    const senha = document.getElementById("senha").value;
    const tipo = document.getElementById("tipo").value;

    if (tipo === "professor") {
        if (usuario === "prof" && senha === "123") {
            localStorage.setItem("tipo", "professor");
            window.location.href = "index.html";
        } else {
            alert("Login de professor inválido");
        }
    } 
    
    if (tipo === "aluno") {
        if (usuario.length > 2) {
            localStorage.setItem("tipo", "aluno");
            localStorage.setItem("nomeAlunoLogado", usuario);
            window.location.href = "index.html";
        } else {
            alert("Digite um nome válido");
        }
    }
}
