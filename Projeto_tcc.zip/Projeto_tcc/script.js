// ------------------------------
// VERIFICAÇÃO DE LOGIN (Proteção da página)
// ------------------------------
const tipoUsuario = localStorage.getItem("tipo");
const nomeLogado = localStorage.getItem("nomeAlunoLogado");

// Se não houver tipo de usuário no sistema, manda para o login
if (!tipoUsuario) {
    if (!window.location.href.includes("login.html")) {
        window.location.href = "login.html";
    }
}

// ------------------------------
// Banco de dados (LocalStorage)
// ------------------------------
let dados = JSON.parse(localStorage.getItem("jogos")) || {
    "Vôlei": { Masculino: [], Feminino: [] },
    "Handebol": { Masculino: [], Feminino: [] },
    "Futsal": { Masculino: [], Feminino: [] },
    "Basquete": { Masculino: [], Feminino: [] }
};

let modalidadeAtual = "Vôlei";
let sexoAtual = "Masculino";
let editIndex = null;
const LIMITE = 12;

// ------------------------------
// Trocar modalidade
// ------------------------------
document.querySelectorAll(".card").forEach(card => {
    card.addEventListener("click", () => {
        document.querySelector(".card.active").classList.remove("active");
        card.classList.add("active");
        modalidadeAtual = card.textContent;
        renderTabela();
    });
});

// ------------------------------
// Trocar sexo
// ------------------------------
document.querySelectorAll(".sexo-btn").forEach(btn => {
    btn.addEventListener("click", () => {
        document.querySelector(".sexo-btn.active").classList.remove("active");
        btn.classList.add("active");
        sexoAtual = btn.textContent;
        renderTabela();
    });
});

// ------------------------------
// Adicionar / Editar aluno
// ------------------------------
function adicionarAluno() {
    const nome = document.getElementById("nomeAluno").value.trim();
    const turma = document.getElementById("turmaAluno").value.trim();
    const posicao = document.getElementById("posicaoAluno").value;

    if (!nome || !turma) {
        alert("Preencha todos os campos!");
        return;
    }

    const lista = dados[modalidadeAtual][sexoAtual];
    if (lista.length >= LIMITE && editIndex === null) {
        alert("Limite de jogadores atingido!");
        return;
    }

    if (editIndex !== null) {
        lista[editIndex] = { nome, turma, posicao };
        editIndex = null;
    } else {
        lista.push({ nome, turma, posicao });
    }

    limparCampos();
    salvar();
    renderTabela();
}

// ------------------------------
// Renderizar tabela
// ------------------------------
function renderTabela() {
    const tabela = document.getElementById("tabela-alunos");
    const busca = document.getElementById("busca")?.value.toLowerCase() || "";
    tabela.innerHTML = "";

    const lista = dados[modalidadeAtual][sexoAtual];

    lista.forEach((aluno, index) => {
        if (!aluno.nome.toLowerCase().includes(busca)) return;

        // Lógica de botões: Professor vê tudo, Aluno só vê o botão "Sair" no próprio nome
        let botoes = "";
        if (tipoUsuario === "professor") {
            botoes = `<button onclick="editarAluno(${index})">✏️</button> 
                      <button onclick="removerAluno(${index})">🗑️</button>`;
        } else if (aluno.nome === nomeLogado) {
            botoes = `<button onclick="removerAluno(${index})">Sair</button>`;
        }

        tabela.innerHTML += `<tr>
            <td>${aluno.nome}</td>
            <td>${aluno.turma}</td>
            <td><span class="badge ${aluno.posicao.toLowerCase()}">${aluno.posicao}</span></td>
            <td>${botoes}</td>
        </tr>`;
    });

    if(document.getElementById("contador")) {
        document.getElementById("contador").textContent = `${lista.length}/${LIMITE} jogadores`;
    }
    if(document.getElementById("tituloLista")) {
        document.getElementById("tituloLista").textContent = `${modalidadeAtual} - ${sexoAtual}`;
    }
}

// ------------------------------
// Remover aluno
// ------------------------------
function removerAluno(index) {
    if (confirm("Deseja remover este registro?")) {
        dados[modalidadeAtual][sexoAtual].splice(index, 1);
        salvar();
        renderTabela();
    }
}

// ------------------------------
// Editar aluno
// ------------------------------
function editarAluno(index) {
    const aluno = dados[modalidadeAtual][sexoAtual][index];
    document.getElementById("nomeAluno").value = aluno.nome;
    document.getElementById("turmaAluno").value = aluno.turma;
    document.getElementById("posicaoAluno").value = aluno.posicao;
    editIndex = index;
}

// ------------------------------
// Limpar campos
// ------------------------------
function limparCampos() {
    document.getElementById("nomeAluno").value = "";
    document.getElementById("turmaAluno").value = "";
}

// ------------------------------
// Logout (IMPORTANTE: Não limpa o banco de dados)
// ------------------------------
function logout() {
    localStorage.removeItem("tipo");
    localStorage.removeItem("nomeAlunoLogado");
    window.location.href = "login.html";
}

// ------------------------------
// Salvar e Busca
// ------------------------------
function salvar() {
    localStorage.setItem("jogos", JSON.stringify(dados));
}

document.getElementById("busca")?.addEventListener("input", renderTabela);

// Inicializar
renderTabela();
